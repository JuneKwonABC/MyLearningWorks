/** [Computational Model of Gas Turbine Engine]
	: This program allows simulation of the general gas-turbine
	engine to evaluate its performance at various conditions.
	(it requires "AirTable.txt" for property table.)
    @file     main.cpp
    @author   June Kwon
    @version  1.2
*/

#include <iostream>
#include <fstream>
using namespace std;
// #include <iomanip>
// #include <string>
// #include <stdio.h>
// #include <math.h>

//++++++++++++++++++++++++++++[Super Class : "parts"]++++++++++++++++++++++++++++

/** [parts]
    : "parts" is the base class for various components throughout
	the entire program. It has thermodynamic properties such as
	temperature, pressure, relative pressure, enthalpy, etc.
*/
class parts
{
	public:
		double T;					// Temperature		 (R)
		double P;					// Pressure 		 (psia)
		double Pr;					// Relative Pressure
		double H;					// Enthalpy			 (Btu/lbm)
		double M;					// Mass Flow Rate	 (lbm/sec)
		void propertyTable(char);	// Look Up Property Table
		void assign(char,double);	// Assign Values
		void display();				// Display Information
};

/** [propertyTable]
    : "propertyTable" method accesses the file "AirTable.txt"
	to find the matching values for the unknown properties by
	specifying the known property
    @param - Known Property (EX: T, H, R)
*/
void parts::propertyTable(char knownProperty)
{
	// Initialization
	string line, vec[3];
	double table_T, table_H, table_Pr;
	int i, pos;

	// Access "AirTable.txt" & File Check
	ifstream infile;
	infile.open("AirTable.txt");
	if (!infile)
	{
		cout << "Cannot Open File!\n";
		exit(1);
	}

	// Find Values from Table
	while (getline(infile, line))
	{
		for  (i = 0; i < 3; i++)
		{
			pos = line.find(',');
			vec[i] = line.substr(0, pos);
			line = line.substr(pos + 1);
		}
		table_T  = atof(vec[0].c_str());
		table_H  = atof(vec[1].c_str());
		table_Pr = atof(vec[2].c_str());

		// If T is known, then H and Pr will be found from table
		if (knownProperty == 'T' && this->T <= table_T)
		{
			H = table_H;
			Pr = table_Pr;
			break;
		}

		// If H is known, then T and Pr will be found from table
		if (knownProperty == 'H' && this->H <= table_H)
		{
			T = table_T;
			Pr = table_Pr;
			break;
		}

		// If R is known, then T and H will be found from table
		if (knownProperty == 'R' && this->Pr <= table_Pr)
		{
			T = table_T;
			H = table_H;
			break;
		}
	}
	infile.close();
}

/** [assign]
    : "assign" method assigns the value for the known property
	by specifying the known property with its value
    @param - Known Property (EX: T, H, R)
	@param - Value for the known property
*/
void parts::assign(char knownProperty, double value)
{
	switch (knownProperty)
	{
		// If the known property is temperature (T),
		// the user specified value will be assigned to T
		case 'T':		
			T = value;	
			break;

		// If the known property is pressure (P),
		// the user specified value will be assigned to P
		case 'P':
			P = value;
			break;

		// If the known property is relative pressure (Pr),
		// the user specified value will be assigned to Pr
		case 'R':
			Pr = value;
			break;

		// If the known property is enthalpy (H),
		// the user specified value will be assigned to H
		case 'H':
			H = value;
			break;

		// If the known property is mass flow rate (M),
		// the user specified value will be assigned to M
		case 'M':
			M = value;
	}
}

/** [display]
    : "parts::display" prints the entire thermodynamic properties
	(T, P, Pr, H, M) of the object.
*/
void parts::display()
{
	cout << "\nTemperature:\t\t" << T << " \t\t(R)";
	cout << "\nPressure:\t\t\t" << P << "\t\t(psia)";
	cout << "\nRelative Pressure:\t" << Pr;
	cout << "\nEnthalpy:\t\t\t" << H << " \t\t(Btu/lbm)";
	cout << "\nMass Flow Rate:\t\t" << M << "  \t\t(lbm/sec)";
	cout << endl;
}

//++++++++++++++++++++++++++[Sub Class : "compressor"]++++++++++++++++++++++++++

// Forward Declaration
class compressor_actualState;
class compressor_isenState;

/** [compressor]
    : "compressor" is a derived class that inherits from "parts" class.
	In addition to what is derived from "parts" class, "compressor"
	class has efficiency, work, power, and partsName.
*/
class compressor : public parts
{
	public:
		string partsName = "Compressor";
		double efficiency;
		double work;
		double power;
		auto calcPerformance(compressor_actualState, compressor_actualState, compressor_isenState);
};

//++++++++++++++++++[Sub Sub Class : "compressor_actualState"]++++++++++++++++++

/** [compressor_actualState]
    : "compressor_actualState" is a derived class that inherits from
	"compressor" class. This class is to analyze the performance of
	the compressor at its actual state.
	(In addition to "compressor" class, this class has stateNum.)
*/
class compressor_actualState : public compressor
{
	public:
		compressor_actualState(string num) // Constructor
		{
			T  = 0;
			P  = 0;
			Pr = 0;
			H  = 0;
			M  = 0;
			stateNum = num;
		}
		string stateNum;
		void display();
		friend auto compressor::calcPerformance(compressor_actualState, compressor_actualState, compressor_isenState);
};

/** [display]
    : "compressor_actualState::display" overrides the "parts::display".
	In addition, partsName and stateNum are printed.
*/
void compressor_actualState::display()
{
	cout << "\n-----------------[State " << stateNum << "]-----------------";
	cout << "\nPart Name:\t\t\t" << partsName;
	cout << "\nState #:\t\t\t" << stateNum << "\t\t\t(Actual)";
	parts::display(); // Override
}

//+++++++++++++++++++[Sub Sub Class : "compressor_isenState"]+++++++++++++++++++

/** [compressor_isenState]
    : "compressor_isenState" is a derived class that inherits from
	"compressor" class. This class is to analyze the performance of
	the compressor at its isentropic state.
	(In addition to "compressor" class, this class has stateNum.)
*/
class compressor_isenState : public compressor
{
	public:
		compressor_isenState(string num) // Constructor
		{
			T  = 0;
			P  = 0;
			Pr = 0;
			H  = 0;
			M  = 0;
			stateNum = num;
		}
		string stateNum;
		void display();
		friend auto calcPerformance(compressor_actualState, compressor_actualState, compressor_isenState);
};

/** [display]
    : "compressor_isenState::display" overrides the "parts::display".
	In addition, partsName and stateNum are printed.
*/
void compressor_isenState::display()
{
	cout << "\n-----------------[State " << stateNum << "]-----------------";
	cout << "\nPart Name:\t\t\t" << partsName;
	cout << "\nState #:\t\t\t" << stateNum << "\t\t\t(Isentropic)";
	parts::display(); // Override
}

/** [calcPerformance]
    : "calcPerformance" calculates the performance of the compressor
	(efficiency, work, power) and print the result.
	@param - Actual Compressor Inlet State
	@param - Actual Compressor Outlet State
	@param - Isentropic Compressor Outlet State
	@return - Efficiency, Work, Power of Compressor
*/
auto compressor::calcPerformance(compressor_actualState actPtr1, compressor_actualState actPtr2, compressor_isenState isnPtr2)
{
	struct result
	{
		double value_efficiency;
		double value_work;
		double value_power;
	};

	// Performance Calculation
	efficiency = (isnPtr2.H - actPtr1.H) / (actPtr2.H - actPtr1.H) * 100;
	work = (actPtr2.H - actPtr1.H);
	power = (M * work);

	// Print
	cout << "\n------------[Performance of Compressor]------------";
	cout << "\nEfficiency of Compressor:\t\t" << efficiency << "\t(%)";
	cout << "\nWork Done on Compressor:\t\t" << work << "\t(Btu/lbm)";
	cout << "\nPower Required by Compressor:\t" << power << "\t(Btu/sec)";
	cout << endl;

	return result {efficiency, work, power};
}

//+++++++++++++++++++++++++++[Sub Class : "combustor"]+++++++++++++++++++++++++++

// Forward Declaration
class combustor_actualState;

/** [combustor]
    : "combustor" is a derived class that inherits from "parts" class.
	In addition to what is derived from "parts" class, "combustor"
	class has heat, heatRate and partsName.
*/
class combustor : public parts
{
	public:
		string partsName = "Combustor";
		double heat;
		double heatRate;
		auto calcPerformance(combustor_actualState, compressor_actualState);
};

//+++++++++++++++++++[Sub Sub Class : "combustor_actualState"]+++++++++++++++++++

/** [combustor_actualState]
    : "combustor_actualState" is a derived class that inherits from
	"combustor" class. This class is to analyze the performance of
	the combustor at its actual state.
	(In addition to "combustor" class, this class has stateNum and
	lowerHeatingValue.)
*/
class combustor_actualState : public combustor
{
	public:
		combustor_actualState(string num1, double num2) // Constructor
		{
			T  = 0;
			P  = 0;
			Pr = 0;
			H  = 0;
			M  = 0;
			stateNum = num1;
			lowerHeatingValue = num2;
		}
		string stateNum;
		double lowerHeatingValue;
		double calcFuelFlowRate(combustor_actualState, compressor_actualState);
		void display();
		friend auto combustor::calcPerformance(combustor_actualState, compressor_actualState);
};

/** [calcFuelFlowRate]
    : "calcFuelFlowRate" calculates the fuel flow rate into the combustor,
	required to satisfy the compressor power requirement and returns
	the result.
	@param - Actual Combustor State
	@param - Actual Compressor Outlet State
	@return - Fuel Flow Rate into Combustor
*/
double combustor_actualState::calcFuelFlowRate(combustor_actualState cmbPtr, compressor_actualState cprPtr)
{
	double fuelFlowRate = (((cprPtr.M * cprPtr.H) - (cmbPtr.M * cmbPtr.H)) / (cmbPtr.H - cmbPtr.lowerHeatingValue));
	this->M = fuelFlowRate + this->M; // Update Current Fuel Flow Rate
	return fuelFlowRate;
}

/** [display]
    : "combustor_actualState::display" overrides the "parts::display".
	In addition, partsName and stateNum are printed.
*/
void combustor_actualState::display()
{
	cout << "\n-----------------[State " << stateNum << "]-----------------";
	cout << "\nPart Name:\t\t\t" << partsName;
	cout << "\nState #:\t\t\t" << stateNum << "\t\t\t(Actual)";
	parts::display(); // Override
}

/** [calcPerformance]
    : "calcPerformance" calculates the performance of the combustor
	(heat, heatRate) and print the result.
	@param - Actual Combustor State
	@param - Actual Compressor Outlet State
	@return - Heat and Heat Rate of Compressor
*/
auto combustor::calcPerformance(combustor_actualState cmbPtr, compressor_actualState cprPtr)
{
	struct result
	{
		double value_heat;
		double value_heatRate;
	};

	// Performance Calculation
	heat = (cmbPtr.H - cprPtr.H);
	heatRate = (cmbPtr.M * cmbPtr.H) - (cprPtr.M * cprPtr.H);
	
	// Print
	cout << "\n-------------[Performance of Combustor]-------------";
	cout << "\nFuel Flow Rate into Combustor:\t" << cmbPtr.M << "\t(lbm/sec)";
	cout << "\nHeat Added to Combustor:\t\t" << heat << "\t(Btu/lbm)";
	cout << "\nHeat Rate Added to Combustor:\t" << heatRate << "\t(Btu/sec)";
	cout << endl;
	
	return result {heat, heatRate};
}

//++++++++++++++++++++++++++++[Sub Class : "turbine"]++++++++++++++++++++++++++++

/** [turbine]
    : "turbine" is a derived class that inherits from "parts" class.
	In addition to what is derived from "parts" class, "turbine"
	class has efficiency, work, and power.
*/
class turbine : public parts
{
	public:
		double efficiency;
		double work;
		double power;
};

//++++++++++++++++++++++++[Sub Sub Class : "GGT_turbine"]++++++++++++++++++++++++

// Forward Declaration
class GGT_turbine_actualState;
class GGT_turbine_isenState;

/** [GGT_turbine]
    : "GGT_turbine" is a derived class that inherits from "turbine" class.
	(In addition to "turbine", this class has partsName and mechanicalLoass.)
	(GGT stands for Gas Generator Turbine.)
*/
class GGT_turbine : public turbine
{
	public:
		string partsName = "Gas Generator Turbine";
		double mechanicalLoss;
		auto calcPerformance(GGT_turbine_actualState, GGT_turbine_isenState, combustor_actualState);
};

//++++++++++++++++[Sub Sub Sub Class : "GGT_turbine_actualState"]++++++++++++++++

/** [GGT_turbine_actualState]
    : "GGT_turbine_actualState" is a derived class that inherits from
	"GGT_turbine" class. This class is to analyze the performance of
	the gas generator turbine at its actual state.
	(In addition to "GGT_turbine" class, this class has stateNum.)
	(GGT stands for Gas Generator Turbine.)
*/
class GGT_turbine_actualState : public GGT_turbine
{
	public:
		GGT_turbine_actualState(string num1, double num2) // Constructor
		{
			T  = 0;
			P  = 0;
			Pr = 0;
			H  = 0;
			M  = 0;
			stateNum = num1;
			mechanicalLoss = num2;
		}
		string stateNum;
		void calcEnthalpy(GGT_turbine_actualState, combustor_actualState, compressor_actualState, compressor_actualState);
		void display();
		friend auto GGT_turbine::calcPerformance(GGT_turbine_actualState, GGT_turbine_isenState, combustor_actualState);
};

/** [calcEnthalpy]
    : "calcEnthalpy" calculates the enthalpy of the gas generator turbine.
	This calculation involves mechanical losses.
	@param - Actual Gas Generator Turbine State
	@param - Actual Combustor State
	@param - Actual Compressor Inlet State
	@param - Actual Compressor Outlet State
*/
void GGT_turbine_actualState::calcEnthalpy(GGT_turbine_actualState ggtPtr, combustor_actualState cmbPtr, compressor_actualState cprPtr1, compressor_actualState cprPtr2)
{
	// Enthalpy Calculation
	this->H = (((1 + ggtPtr.mechanicalLoss) * (cprPtr2.M) * (cprPtr1.H - cprPtr2.H)) / ggtPtr.M) + cmbPtr.H;
}

/** [display]
    : "GGT_turbine_actualState::display" overrides the "parts::display".
	In addition, partsName and stateNum are printed.
*/
void GGT_turbine_actualState::display()
{
	cout << "\n-----------------[State " << stateNum << "]-----------------";
	cout << "\nPart Name:\t\t\t" << partsName;
	cout << "\nState #:\t\t\t" << stateNum << "\t\t\t(Actual)";
	parts::display(); // Override
}

//+++++++++++++++++[Sub Sub Sub Class : "GGT_turbine_isenState"]+++++++++++++++++

/** [GGT_turbine_isenState]
    : "GGT_turbine_isenState" is a derived class that inherits from
	"GGT_turbine" class. This class is to analyze the performance of
	the gas generator turbine at its isentropic state.
	(In addition to "GGT_turbine" class, this class has stateNum.)
	(GGT stands for Gas Generator Turbine.)
*/
class GGT_turbine_isenState : public GGT_turbine
{
	public:
		GGT_turbine_isenState(string num1, double num2) // Constructor
		{
			T  = 0;
			P  = 0;
			Pr = 0;
			H  = 0;
			M  = 0;
			stateNum = num1;
			mechanicalLoss = num2;
		}
		string stateNum;
		void calcRelativePressure(GGT_turbine_isenState, combustor_actualState);
		void display();
		friend auto GGT_turbine::calcPerformance(GGT_turbine_actualState, GGT_turbine_isenState, combustor_actualState);
};

/** [calcRelativePressure]
    : "calcRelativePressure" calculates the relative pressure of the gas
	generator turbine. This calculation involves the pressure and the
	relative pressure of the combustor.
	@param - Isentropic Gas Generator Turbine State
	@param - Actual Combustor State
*/
void GGT_turbine_isenState::calcRelativePressure(GGT_turbine_isenState ggtPtr, combustor_actualState cmbPtr)
{
	this->Pr = cmbPtr.Pr * (ggtPtr.P / cmbPtr.P);
}

/** [display]
    : "GGT_turbine_isenState::display" overrides the "parts::display".
	In addition, partsName and stateNum are printed.
*/
void GGT_turbine_isenState::display()
{
	cout << "\n-----------------[State " << stateNum << "]-----------------";
	cout << "\nPart Name:\t\t\t" << partsName;
	cout << "\nState #:\t\t\t" << stateNum << "\t\t\t(Isentropic)";
	parts::display(); // Override
}

/** [calcPerformance]
    : "calcPerformance" calculates the performance of the gas generator
	turbine (efficiency, work, power) and print the result.
	@param - Actual Gas Generator Turbine State
	@param - Isentropic Gas Generator Turbine State
	@param - Actual Combustor State
	@return - Efficiency, Work, Power of Gas Generator Turbine
*/
auto GGT_turbine::calcPerformance(GGT_turbine_actualState actPtr, GGT_turbine_isenState isnPtr, combustor_actualState cmbPtr)
{
	struct result
	{
		double value_efficiency;
		double value_work;
		double value_power;
	};

	// Performance Calculation
	efficiency = (cmbPtr.H - actPtr.H) / (cmbPtr.H - isnPtr.H) * 100;
	work = (cmbPtr.H - actPtr.H);
	power = (M * work);

	// Print
	cout << "\n-------[Performance of Gas Generator Turbine]-------";
	cout << "\nEfficiency of GGT Turbine:\t\t" << efficiency << "\t(%)";
	cout << "\nWork Done by GGT Turbine:\t\t" << work << "\t(Btu/lbm)";
	cout << "\nPower Generated by GGT Turbine:\t" << power << "\t(Btu/sec)";
	cout << endl;

	return result {efficiency,work,power};
}

//++++++++++++++++++++++++[Sub Sub Class : "PWR_turbine"]++++++++++++++++++++++++

// Forward Declaration
class PWR_turbine_actualState;
class PWR_turbine_isenState;

/** [PWR_turbine]
    : "PWR_turbine" is a derived class that inherits from "turbine" class.
	(In addition to "turbine", this class has partsName.)
	(PWR stands for Power Turbine.)
*/
class PWR_turbine : public turbine
{
	public:
		string partsName = "Power Turbine";
		auto calcPerformance(PWR_turbine_actualState, PWR_turbine_isenState, GGT_turbine_actualState);
};

//++++++++++++++++[Sub Sub Sub Class : "PWR_turbine_actualState"]++++++++++++++++

/** [PWR_turbine_actualState]
    : "PWR_turbine_actualState" is a derived class that inherits from
	"PWR_turbine" class. This class is to analyze the performance of
	the power turbine at its actual state.
	(In addition to "PWR_turbine" class, this class has stateNum.)
	(PWR stands for Power Turbine.)
*/
class PWR_turbine_actualState : public PWR_turbine
{
	public:
		PWR_turbine_actualState(string num) // Constructor
		{
			T  = 0;
			P  = 0;
			Pr = 0;
			H  = 0;
			M  = 0;
			stateNum = num;
		}
		string stateNum;
		void display();
		friend auto PWR_turbine::calcPerformance(PWR_turbine_actualState, PWR_turbine_isenState, GGT_turbine_actualState);
};

/** [display]
    : "PWR_turbine_actualState::display" overrides the "parts::display".
	In addition, partsName and stateNum are printed.
*/
void PWR_turbine_actualState::display()
{
	cout << "\n-----------------[State " << stateNum << "]-----------------";
	cout << "\nPart Name:\t\t\t" << partsName;
	cout << "\nState #:\t\t\t" << stateNum << "\t\t\t(Actual)";
	parts::display(); // Override
}

//+++++++++++++++++[Sub Sub Sub Class : "PWR_turbine_isenState"]+++++++++++++++++

/** [PWR_turbine_isenState]
    : "PWR_turbine_isenState" is a derived class that inherits from
	"PWR_turbine" class. This class is to analyze the performance of
	the power turbine at its isentropic state.
	(In addition to "PWR_turbine" class, this class has stateNum.)
	(PWR stands for Gas Generator Turbine.)
*/
class PWR_turbine_isenState : public PWR_turbine
{
	public:
		PWR_turbine_isenState(string num) // Constructor
		{
			T  = 0;
			P  = 0;
			Pr = 0;
			H  = 0;
			M  = 0;
			stateNum = num;
		}
		string stateNum;
		void calcRelativePressure(PWR_turbine_isenState, GGT_turbine_actualState);
		void display();
		friend auto PWR_turbine::calcPerformance(PWR_turbine_actualState, PWR_turbine_isenState, GGT_turbine_actualState);
};

/** [calcRelativePressure]
    : "calcRelativePressure" calculates the relative pressure of the
	power turbine. This calculation involves the pressure and the
	relative pressure of the gas generator turbine.
	@param - Isentropic Power Turbine State
	@param - Actual Gas Generator Turbine State
*/
void PWR_turbine_isenState::calcRelativePressure(PWR_turbine_isenState pwrPtr, GGT_turbine_actualState ggtPtr)
{
	this->Pr = ggtPtr.Pr * (pwrPtr.P / ggtPtr.P);
}

/** [display]
    : "PWR_turbine_isenState::display" overrides the "parts::display".
	In addition, partsName and stateNum are printed.
*/
void PWR_turbine_isenState::display()
{
	cout << "\n-----------------[State " << stateNum << "]-----------------";
	cout << "\nPart Name:\t\t\t" << partsName;
	cout << "\nState #:\t\t\t" << stateNum << "\t\t\t(Isentropic)";
	parts::display(); // Override
}

/** [calcPerformance]
    : "calcPerformance" calculates the performance of the power
	turbine (efficiency, work, power) and print the result.
	@param - Actual Power Turbine State
	@param - Isentropic Power Turbine State
	@param - Actual Gas Generator Turbine State
	@return - Efficiency, Work, Power of Power Turbine
*/
auto PWR_turbine::calcPerformance(PWR_turbine_actualState actPtr, PWR_turbine_isenState isnPtr, GGT_turbine_actualState ggtPtr)
{
	struct result
	{
		double value_efficiency;
		double value_work;
		double value_power;
	};

	// Performance Calculation
	efficiency = (ggtPtr.H - actPtr.H) / (ggtPtr.H - isnPtr.H) * 100;
	work = (ggtPtr.H - actPtr.H);
	power = (M * work);

	// Print
	cout << "\n-----------[Performance of Power Turbine]-----------";
	cout << "\nEfficiency of PWR Turbine:\t\t" << efficiency << "\t(%)";
	cout << "\nWork Done by PWR Turbine:\t\t" << work << "\t(Btu/lbm)";
	cout << "\nPower Generated by PWR Turbine:\t" << power << "\t(Btu/sec)";
	cout << endl;

	return result {efficiency, work, power};
}

/** [calcNETPerformance]
    : "calcNETPerformance" calculates the performance (efficiency, work, power)
	of the entire gas turbine as a net system and print the result.
	@param - Isentropic Power Turbine State
	@param - Actual Combustor State
	@param - Mass Flow Rate
	@return - Efficiency, Work, Power of Net Gas Turbine System
*/
auto calcNETPerformance(PWR_turbine_isenState isnPtr, combustor_actualState cmbPtr, double MFR)
{
	struct result
	{
		double value_efficiency;
		double value_work;
		double value_power;
		double value_ratio;
	};
	
	// Performance Calculation
	double netEfficiency = (isnPtr.power / cmbPtr.heatRate) * 100;
	double netWork = isnPtr.work;
	double netPower = isnPtr.power;
	double netRatio = ((cmbPtr.M - MFR) / MFR);

	// Print
	cout << "\n---[Net Performance of Entire Gas Turbine System]---";
	cout << "\nEfficiency of Net Cycle System:\t" << netEfficiency << "\t(%)";
	cout << "\nWork Done by Net Cycle System:\t" << netWork << "\t(Btu/lbm)";
	cout << "\nPower Generated by Net System:\t" << netPower << "\t(Btu/sec)";
	cout << "\nFuel/Air Mass Flow Ratio:\t\t" << netRatio;
	cout << endl;

	return result {netEfficiency, netWork, netPower, netRatio};
}

//+++++++++++++++++++++++++++++++++[Main Script]+++++++++++++++++++++++++++++++++

int main()
{
	// Given Conditions
	double RPC = 21.8090;		// Compressor Pressure Ratio
	double MFR = 50.0000; 		// Mass Flow Rate (lbm/sec)
	double FFR = 0.00000;		// Fuel Flow Rate (lbm/sec)
	double DRP = 0.10000;		// 10% Pressure Drop
	double MLS = 0.09470;		// 9.47% Mechanical Losses
	double LHV = 19098.0;		// Lower Heating Value of n-Octane (Btu/lbm)
	double T1  = 560.000;		// Compressor Inlet Temperature (R)
	double T2A = 1450.00;		// Compressor Outlet Temperature (R)
	double T3A = 2800.00;		// Combustor Outlet Temperature (R)
	double T5A = 1500.00;		// Power Turbine Outlet Temperature (R)
	double P1  = 14.7000;		// Compressor Inlet Pressure (psia)
	double P4A = 51.3100;		// Gas Generator Turbine Outlet Pressure (psia)
	double P5A = 15.2800;		// Power Turbine Outlet Pressure (psia)

	// 1. Compressor Inlet ++++++++++++++++++++++++++++++++++++++++++++++++++++++

	compressor_actualState state1("1");		// Define State 1
	state1.assign('M',MFR);					// Assign Known Properties at State 1
	state1.assign('T',T1);
	state1.assign('P',P1);
	state1.propertyTable('T');				// Find other unknown properties
	state1.display();						// Display all properties at State 1

	// 2. Compressor Outlet +++++++++++++++++++++++++++++++++++++++++++++++++++++

	compressor_actualState state2A("2A");	// Define State 2A (Actual)
	state2A.assign('M',MFR);				// Assign Known Properties at State 2A
	state2A.assign('T',T2A);
	state2A.assign('P',RPC*state1.P);
	state2A.propertyTable('T');				// Find other unknown properties
	state2A.display();						// Display all properties at State 2A
	
	compressor_isenState state2S("2S");		// Define State 2S (Isentropic)
	state2S.assign('M',MFR);				// Assign Known Properties at State 2S
	state2S.assign('P',state2A.P);
	state2S.assign('R',RPC*state1.Pr);
	state2S.propertyTable('R');				// Find other unknown properties
	state2S.display();						// Display all properties at State 2S
	
	// 3. Combustor +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	combustor_actualState state3("3",LHV);	// Define State 3 (Actual)
	state3.assign('M',MFR);					// Assign Known Properties at State 3
	state3.assign('T',T3A);
	state3.assign('P',(1-DRP)*state2A.P);
	state3.propertyTable('T');				// Find other unknown properties
	FFR = state3.calcFuelFlowRate(state3,state2A);
	state3.display();						// Display all properties at State 3

	// 4. Gas Generator Turbine +++++++++++++++++++++++++++++++++++++++++++++++++

	GGT_turbine_actualState state4A("4A",MLS); // Define State 4A (Actual)
	state4A.assign('M',MFR+FFR);			// Assign Known Properties at State 4A
	state4A.assign('P',P4A);
	state4A.calcEnthalpy(state4A,state3,state1,state2A);
	state4A.propertyTable('H');				// Find other unknown properties
	state4A.display();						// Display all properties at State 4A

	GGT_turbine_isenState state4S("4S",MLS);// Define State 4S (Isentropic)
	state4S.assign('M',MFR+FFR);			// Assign Known Properties at State 4S
	state4S.assign('P',P4A);
	state4S.calcRelativePressure(state4S,state3);
	state4S.propertyTable('R');				// Find other unknown properties
	state4S.display();						// Display all properties at State 4S

	// 5. Power Turbine +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	PWR_turbine_actualState state5A("5A");	// Define State 5A (Actual)
	state5A.assign('M',MFR+FFR);			// Assign Known Properties at State 5A
	state5A.assign('T',T5A);
	state5A.assign('P',P5A);
	state5A.propertyTable('T');				// Find other unknown properties
	state5A.display();						// Display all properties at State 5A

	PWR_turbine_isenState state5S("5S");	// Define State 5S (Isentropic)
	state5S.assign('M',MFR+FFR);			// Assign Known Properties at State 5S
	state5S.assign('P',P5A);
	state5S.calcRelativePressure(state5S, state4A);
	state5S.propertyTable('R');				// Find other unknown properties
	state5S.display();						// Display all properties at State 5S

	// 6. NET Performance Evaluation ++++++++++++++++++++++++++++++++++++++++++++

	state2S.calcPerformance(state1,state2A,state2S);	// Compressor Performance
	state3.calcPerformance(state3,state2A);				// Combustor Performance
	state4S.calcPerformance(state4A,state4S,state3);	// GGT Turbine Performance
	state5S.calcPerformance(state5A,state5S,state4A);	// PWR Turbine Performance
	calcNETPerformance(state5S,state3,MFR);				// NET System Performance

	// End of Program
	// June Kwon
}